import sys
from org.joda.time import DateTime
from org.joda.time.format import ISODateTimeFormat

def filterEmpty(arr):
  return [str(a.strip()) for a in arr if a is not None and len(a.strip()) > 0]

dateFormatter = ISODateTimeFormat.dateTime()
todayAt11am = DateTime()
todayAt11am = todayAt11am.withHourOfDay(11).withMinuteOfHour(0).withSecondOfMinute(0)
yesterdayAt11am = todayAt11am.minusDays(1)


itemsOnTrain = []

myFile = open(fileLocation, 'r')
for line in myFile:
  items = line.split(",")
  itemDateTime = dateFormatter.parseDateTime(items[0])
  if itemDateTime.isAfter(yesterdayAt11am) and itemDateTime.isBefore(todayAt11am):
    itemsOnTrain.append(items[1])

myFile.close()

itemsOnTrain = filterEmpty(itemsOnTrain)
