import sys
from org.joda.time import DateTime
from org.joda.time.format import ISODateTimeFormat

def filterEmpty(arr):
  return [a.strip() for a in arr if a is not None and len(a.strip()) > 0]

def splitList(arr, delimiter=","):
  if arr is None or len(arr.strip()) == 0:
    return []
  return filterEmpty(arr.split(delimiter))

def roleArtifactListToMap(artifactList):
  roleArtifactMap = {}
  for roleArtifact in artifactList:
    (role, artifact) = roleArtifact.split(':')
    artifactsForRole = []
    if role in roleArtifactMap:
      artifactsForRole = roleArtifactMap[role]
    else:
      roleArtifactMap[role] = artifactsForRole
    artifactsForRole.append(artifact)
  return roleArtifactMap


roleArtifactMap = roleArtifactListToMap(splitList(itemsToDeploy))

dateFormatter = ISODateTimeFormat.dateTime()
current_time = dateFormatter.print(DateTime())

lines = []
for role, artifacts in roleArtifactMap.items():
  for artifact in artifacts:
    lines.append("%s,%s:%s:%s" % (current_time, role, artifact, releaseVersion))    


myFile = open(fileLocation, 'a')
myFile.write("\n".join(lines))
myFile.close()

