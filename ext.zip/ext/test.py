from random import randint
id = "SNOW-%s" % randint(100, 999)
print id

