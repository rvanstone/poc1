logger.info('************* Testing API extension endpoint')

# response.entity is what will be returned to the client as JSON
response.entity = request.entity
