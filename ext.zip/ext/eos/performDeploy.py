import sys, string

ISSUE_CREATED_STATUS = 201

content = """
""" % (json.dumps(project), json.dumps(title), json.dumps(description), json.dumps(string.capwords(issueType)))

if jiraServer is None:
    print "No server provided."
    sys.exit(1)

jiraURL = jiraServer['url']
if jiraURL.endswith('/'):
    jiraURL = jiraURL[:len(jiraURL)-1]

request = HttpRequest(jiraServer, username, password)
response = request.post('/rest/api/2/issue', content, contentType = 'application/json')

if response.status == ISSUE_CREATED_STATUS:
    data = json.loads(response.response)
    issueId = data.get('key')
    print "Created %s in JIRA at %s." % (issueId, jiraURL)
else:
    print "Failed to create issue in JIRA at %s." % jiraURL
    response.errorDump()
    sys.exit(1)

