from __future__ import with_statement
import com.xhaus.jyson.JysonCodec as json
import os
logger.info('************* Testing API extension endpoint')

# response.entity is what will be returned to the client as JSON
json_data = json.loads(json.dumps(request.entity))
ticketNumber = json_data['ticket'][0]['ticketNumber']
filename = ticketNumber + '.txt'


with open(filename, 'w') as outfile:
  outfile.write(json.dumps(request.entity))

response.entity = request.entity
