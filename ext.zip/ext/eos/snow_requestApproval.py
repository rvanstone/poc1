from __future__ import with_statement
import com.xhaus.jyson.JysonCodec as json
import time

logger.info('************* Testing API extension endpoint')

# response.entity is what will be returned to the client as JSON

status = None
while status != 'Approved':
  data = None
  with open('snow_ticket.txt', 'r') as data_file:    
    data = data_file.read()
    
  json_data = json.loads(data)
  status = json_data['ticket'][0]['status']
  logger.info("In While")
  time.sleep(4)


response.entity = status
