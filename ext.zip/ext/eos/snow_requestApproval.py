from __future__ import with_statement
import com.xhaus.jyson.JysonCodec as json
import time

logger.info('************* Testing API extension endpoint')

# response.entity is what will be returned to the client as JSON
json_ticket = json.loads(json.dumps(request.entity))
ticket = json_ticket['ticketNumber']
status = None
while status != 'Approved':
  data = None
  with open(ticket, 'r') as data_file:    
    data = data_file.read()
    
  json_data = json.loads(data)
  status = json_data['ticket'][0]['status']
  logger.info("In While")
  time.sleep(4)


response.entity = status
