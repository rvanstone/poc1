Put plugin extensions in this directory.
