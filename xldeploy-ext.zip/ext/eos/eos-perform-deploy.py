#context.addStep(steps.jython(description="Perform deployment using EOSLPS", script_path="eos/perform-deploy.py", jython_context={"xml":xml, "restEndpoint": deployedApplication.environment.eosRestApiUrl}))

print "REST %s/deploy?group-id=%s&artifact-id=%s,version=%s&hostname=%s" % (deployedApplication.environment.eosRestApiUrl,deployed.getProperty('groupId'),deployed.getProperty('artifactId'),deployed.getProperty('version'),deployed.container.name)
