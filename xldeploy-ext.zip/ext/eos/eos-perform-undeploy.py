print "REST %s/undeploy?group-id=%s&hostname=%s" % (deployedApplication.environment.eosRestApiUrl,deployed.getProperty('groupId'),deployed.container.name)
