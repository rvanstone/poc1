import urllib2

req = urllib2.Request(restEndpoint, xml, {'Content-Type': 'application/xml'})
#f = urllib2.urlopen(req)
print xml
#response = f.read()
#f.close()

