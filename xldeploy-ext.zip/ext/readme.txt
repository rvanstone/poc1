Put your XL Deploy plugin extensions in this directory.
